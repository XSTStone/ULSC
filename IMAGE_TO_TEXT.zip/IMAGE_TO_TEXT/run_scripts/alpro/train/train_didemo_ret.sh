python -m torch.distributed.run --nproc_per_node=8 train.py --cfg-path lavis/projects/alpro/train/didemo_ret_ft.yaml
