python evaluate.py --cfg-path lavis/projects/gpt/train/dialogue_avsd_ft.yaml
