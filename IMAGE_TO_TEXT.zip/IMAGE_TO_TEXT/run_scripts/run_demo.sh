streamlit run app/main.py --server.fileWatcherType none
